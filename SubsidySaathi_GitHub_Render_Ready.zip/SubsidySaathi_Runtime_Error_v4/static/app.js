'use strict';
const $ = s => document.getElementById(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LANG = {
 en: {navHome:'Home',navSchemes:'Schemes',navResearch:'Research Lab',navApply:'Apply',navTrack:'My Applications',heroEyebrow:'YOUR FARMING COMPANION',heroTitle:'Government schemes.<br><em>Made simple for every farmer.</em>',heroIntro:'Discover benefits. Check requirements. Prepare your application — with a smart assistant built for Indian farmers.',getStarted:'Get started',exploreResearch:'Explore Research Lab →',fourLang:'4 languages',sourceBacked:'Official sources',privatePrep:'Private document preparation',feat1:'Live scheme research',feat1d:'TinyFish reads official portals and returns concise findings.',feat2:'Eligibility clarity',feat2d:'Know what is missing and what needs official verification.',feat3:'Document checklist',feat3d:'Track your paperwork without storing sensitive files.',feat4:'RAG-powered assistant',feat4d:'Get sourced answers through OpenRouter or local retrieval.',profileTitle:'Tell us about your farm',profileSub:'Basic details once. No Aadhaar or bank numbers in this demo.',personalized:'Personalized scheme discovery',farmerName:'Farmer name',state:'State',district:'District',crop:'Primary crop',land:'Land (hectares)',season:'Season',ownership:'Land access',findSchemes:'Find my schemes ↗',schemesTitle:'Recommended for your farm',editProfile:'Edit profile',researchTitle:'Research <em>Lab.</em>',researchSub:'Precise facts. Source links. Maximum 14 short lines.',liveResearch:'Official scheme research',chooseScheme:'Select scheme',chatTitle:'Runny · Your AI buddy',appTitle:'Documents to draft. <em>Sorted.</em>',appSub:'Track missing paperwork, prepare a form and review before visiting the official portal.',docTitle:'Document checklist',previewTitle:'Auto-prepared application',prepare:'Refresh auto-filled form',reviewLabel:'I reviewed this mock form. I understand it has NOT been sent to any government portal.',saveDraft:'Save my draft →',appsTitle:'Application <em>Tracker.</em>',appsSub:'Every saved draft, one clear timeline. Track your preparation and explore clearly labeled demo examples.',newDraft:'+ New application'},
 hi: {navHome:'होम',navSchemes:'योजनाएँ',navResearch:'रिसर्च लैब',navApply:'आवेदन',navTrack:'मेरे आवेदन',heroEyebrow:'आपका खेती साथी',heroTitle:'सरकारी योजनाएँ।<br><em>अब हर किसान के लिए आसान।</em>',heroIntro:'सरकारी सहायता खोजें, पात्रता जाँचें और आवेदन तैयार करें — एक ही जगह।',getStarted:'शुरू करें',exploreResearch:'रिसर्च देखें →',fourLang:'4 भाषाएँ',sourceBacked:'सरकारी स्रोत',privatePrep:'निजी दस्तावेज़ तैयारी',feat1:'लाइव योजना जानकारी',feat1d:'TinyFish सरकारी वेबसाइटों से संक्षिप्त जानकारी पढ़ता है।',feat2:'पात्रता की जानकारी',feat2d:'जानें क्या बाकी है और क्या पुष्टि चाहिए।',feat3:'दस्तावेज़ चेकलिस्ट',feat3d:'संवेदनशील फ़ाइलें सहेजे बिना जाँच करें।',feat4:'RAG सहायक',feat4d:'स्रोत-आधारित जवाब पाएँ।',profileTitle:'अपने खेत के बारे में बताएँ',profileSub:'बुनियादी जानकारी। यहाँ आधार या बैंक नंबर नहीं चाहिए।',personalized:'आपके लिए योजना खोज',farmerName:'किसान का नाम',state:'राज्य',district:'ज़िला',crop:'मुख्य फसल',land:'ज़मीन (हेक्टेयर)',season:'मौसम',ownership:'भूमि का अधिकार',findSchemes:'मेरी योजनाएँ खोजें ↗',schemesTitle:'आपके लिए योजनाएँ',editProfile:'प्रोफाइल बदलें',researchTitle:'रिसर्च <em>लैब।</em>',researchSub:'साफ़ जानकारी, सरकारी स्रोत, अधिकतम 14 पंक्तियाँ।',liveResearch:'सरकारी योजना रिसर्च',chooseScheme:'योजना चुनें',chatTitle:'Runny · आपका AI दोस्त',appTitle:'दस्तावेज़ और <em>आवेदन।</em>',appSub:'दस्तावेज़ जाँचें, ड्राफ्ट बनाएँ और सरकारी वेबसाइट पर खुद जमा करें।',docTitle:'दस्तावेज़ चेकलिस्ट',previewTitle:'पहले से भरा ड्राफ्ट',prepare:'ड्राफ्ट अपडेट करें',reviewLabel:'मैंने नमूना ड्राफ्ट देखा है और समझता हूँ कि सरकारी वेबसाइट पर जमा नहीं हुआ।',saveDraft:'ड्राफ्ट सेव करें →',appsTitle:'आवेदन <em>ट्रैकर।</em>',appsSub:'सेव किए गए ड्राफ्ट और स्पष्ट रूप से चिह्नित नमूना प्रगति।',newDraft:'+ नया आवेदन'},
 bn: {navHome:'হোম',navSchemes:'প্রকল্প',navResearch:'গবেষণা',navApply:'আবেদন',navTrack:'আমার আবেদন',heroEyebrow:'আপনার কৃষি সহায়ক',heroTitle:'সরকারি প্রকল্প।<br><em>এখন সব কৃষকের জন্য সহজ।</em>',heroIntro:'সরকারি সহায়তা খুঁজুন, শর্ত দেখুন এবং আবেদন প্রস্তুত করুন — এক জায়গায়।',getStarted:'শুরু করুন',exploreResearch:'গবেষণা দেখুন →',fourLang:'৪টি ভাষা',sourceBacked:'সরকারি উৎস',privatePrep:'ব্যক্তিগত নথি প্রস্তুতি',feat1:'সরাসরি প্রকল্প তথ্য',feat1d:'TinyFish সরকারি ওয়েবসাইট থেকে তথ্য সংগ্রহ করে।',feat2:'যোগ্যতার তথ্য',feat2d:'কোন তথ্য বাকি আছে জানুন।',feat3:'নথি চেকলিস্ট',feat3d:'সংবেদনশীল ফাইল সংরক্ষণ না করে প্রস্তুতি নিন।',feat4:'RAG সহায়ক',feat4d:'উৎস থেকে উত্তর পান।',profileTitle:'আপনার খামারের তথ্য দিন',profileSub:'শুধু সাধারণ তথ্য; এখানে আধার বা ব্যাঙ্ক নম্বর নয়।',personalized:'ব্যক্তিগত প্রকল্প অনুসন্ধান',farmerName:'কৃষকের নাম',state:'রাজ্য',district:'জেলা',crop:'প্রধান ফসল',land:'জমি (হেক্টর)',season:'মৌসুম',ownership:'জমির অধিকার',findSchemes:'প্রকল্প খুঁজুন ↗',schemesTitle:'আপনার জন্য প্রকল্প',editProfile:'তথ্য বদলান',researchTitle:'গবেষণা <em>ল্যাব।</em>',researchSub:'সংক্ষিপ্ত তথ্য, উৎস লিংক, সর্বোচ্চ ১৪ লাইন।',liveResearch:'সরকারি প্রকল্প গবেষণা',chooseScheme:'প্রকল্প বাছুন',chatTitle:'Runny · আপনার AI বন্ধু',appTitle:'নথি থেকে <em>আবেদন।</em>',appSub:'নথি যাচাই করুন এবং সরকারি পোর্টালের আগে খসড়া দেখুন।',docTitle:'নথি চেকলিস্ট',previewTitle:'প্রস্তুত আবেদন খসড়া',prepare:'খসড়া আপডেট করুন',reviewLabel:'আমি বুঝেছি এই খসড়াটি সরকারি পোর্টালে জমা দেওয়া হয়নি।',saveDraft:'খসড়া সংরক্ষণ →',appsTitle:'আবেদন <em>ট্র্যাকার</em>',appsSub:'সংরক্ষিত খসড়া এবং স্পষ্টভাবে চিহ্নিত নমুনা অগ্রগতি।',newDraft:'+ নতুন আবেদন'},
 te: {navHome:'హోమ్',navSchemes:'పథకాలు',navResearch:'పరిశోధన',navApply:'దరఖాస్తు',navTrack:'నా దరఖాస్తులు',heroEyebrow:'మీ వ్యవసాయ సహాయకుడు',heroTitle:'ప్రభుత్వ పథకాలు.<br><em>ప్రతి రైతుకు సులభంగా.</em>',heroIntro:'ప్రయోజనాలను కనుగొనండి, అర్హతను పరిశీలించండి, దరఖాస్తు సిద్ధం చేసుకోండి.',getStarted:'ప్రారంభించండి',exploreResearch:'పరిశోధన చూడండి →',fourLang:'4 భాషలు',sourceBacked:'అధికారిక సమాచారం',privatePrep:'వ్యక్తిగత పత్రాల సిద్ధం',feat1:'ప్రత్యక్ష పథక పరిశోధన',feat1d:'TinyFish ప్రభుత్వ సైట్ల సమాచారం పరిశీలిస్తుంది.',feat2:'అర్హత స్పష్టత',feat2d:'ఇంకా ఏ సమాచారం అవసరమో తెలుసుకోండి.',feat3:'పత్రాల చెక్‌లిస్ట్',feat3d:'సున్నితమైన ఫైళ్లు భద్రపరచకుండా పత్రాలు ట్రాక్ చేయండి.',feat4:'RAG సహాయకుడు',feat4d:'సోర్స్ ఆధారిత సమాధానాలు పొందండి.',profileTitle:'మీ పొలం వివరాలు చెప్పండి',profileSub:'ప్రాథమిక సమాచారం మాత్రమే; ఆధార్ లేదా బ్యాంకు నంబర్లు వద్దు.',personalized:'వ్యక్తిగత పథక అన్వేషణ',farmerName:'రైతు పేరు',state:'రాష్ట్రం',district:'జిల్లా',crop:'ప్రధాన పంట',land:'భూమి (హెక్టార్లు)',season:'సీజన్',ownership:'భూమి హక్కు',findSchemes:'పథకాలను కనుగొనండి ↗',schemesTitle:'మీకు సరిపోయే పథకాలు',editProfile:'వివరాలు మార్చు',researchTitle:'పరిశోధన <em>ల్యాబ్.</em>',researchSub:'సంక్షిప్త సమాచారం, అధికారిక లింకులు, గరిష్టం 14 పంక్తులు.',liveResearch:'అధికారిక పథక పరిశోధన',chooseScheme:'పథకం ఎంచుకోండి',chatTitle:'Runny · మీ AI స్నేహితుడు',appTitle:'పత్రాల నుండి <em>డ్రాఫ్ట్.</em>',appSub:'పత్రాలు తనిఖీ చేసి ప్రభుత్వ సైట్‌లో పూర్తి చేయడానికి సిద్ధం అవ్వండి.',docTitle:'పత్రాల చెక్‌లిస్ట్',previewTitle:'ముందుగా నింపిన దరఖాస్తు',prepare:'డ్రాఫ్ట్ నవీకరించు',reviewLabel:'ఇది నమూనా డ్రాఫ్ట్ మాత్రమే, ప్రభుత్వానికి పంపలేదని అర్థమైంది.',saveDraft:'డ్రాఫ్ట్ సేవ్ →',appsTitle:'దరఖాస్తు <em>ట్రాకర్</em>',appsSub:'సేవ్ చేసిన డ్రాఫ్ట్‌లు, స్పష్టంగా గుర్తించిన నమూనా పురోగతి.',newDraft:'+ కొత్త దరఖాస్తు'}
};
const DOC_LABELS={
 en:{aadhaar:'Aadhaar / identity proof',land:'Land ownership / cultivation record',bank:'Bank passbook details',mobile:'Mobile access for verification',ekyc:'eKYC completion',sowing:'Crop sowing certificate / declaration'},
 hi:{aadhaar:'आधार / पहचान दस्तावेज़',land:'भूमि / खेती का रिकॉर्ड',bank:'बैंक पासबुक विवरण',mobile:'सत्यापन के लिए मोबाइल',ekyc:'ई-केवाईसी पूरी करें',sowing:'फसल बुवाई प्रमाणपत्र / घोषणा'},
 bn:{aadhaar:'আধার / পরিচয়পত্র',land:'জমির / চাষের নথি',bank:'ব্যাঙ্ক পাসবইয়ের তথ্য',mobile:'যাচাইয়ের মোবাইল',ekyc:'ই-কেওয়াইসি সম্পূর্ণ',sowing:'ফসল বপনের শংসাপত্র / ঘোষণা'},
 te:{aadhaar:'ఆధార్ / గుర్తింపు పత్రం',land:'భూమి / సాగు రికార్డు',bank:'బ్యాంకు పాస్‌బుక్ వివరాలు',mobile:'ధృవీకరణకు మొబైల్',ekyc:'ఈ-కేవైసీ పూర్తి',sowing:'పంట విత్తిన ధృవీకరణ / ప్రకటన'}
};
let language='en';let profile={};let selectedScheme='pmkisan';
const schemeInfo={pmkisan:{name:'PM-KISAN Samman Nidhi',desc:'Income support for eligible landholding farmer families.',icon:'🌾'},pmfby:{name:'Pradhan Mantri Fasal Bima Yojana',desc:'Crop insurance depending on notified crop, season and location.',icon:'🛡️'}};
function notify(msg){const node=$('toast');node.textContent=msg;node.classList.add('show');clearTimeout(notify.timeout);notify.timeout=setTimeout(()=>node.classList.remove('show'),3900)}
async function jsonApi(path, payload){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});let data=await r.json();if(!r.ok)throw Error(data.error||'Request failed');return data}
async function getApi(path){const r=await fetch(path);let data=await r.json();if(!r.ok)throw Error(data.error||'Request failed');return data}
function go(page){document.querySelectorAll('section.page').forEach(n=>n.classList.toggle('shown',n.id===page));document.querySelectorAll('.navbtn').forEach(n=>n.classList.toggle('active',n.dataset.nav===page));window.scrollTo({top:0,behavior:'smooth'});if(page==='application'){renderChecklist();renderPreview()}if(page==='applications')loadDrafts()}
document.querySelectorAll('[data-nav]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault();go(el.dataset.nav)}));
function t(key){return LANG[language][key]||LANG.en[key]||key}
function translate(){document.querySelectorAll('[data-t]').forEach(el=>{const tr=t(el.dataset.t);if(tr)el.innerHTML=tr});document.documentElement.lang=language;if(document.getElementById('application').classList.contains('shown'))renderChecklist();$('chat-question').placeholder={en:'Ask about government schemes…',hi:'सरकारी योजनाओं के बारे में पूछें…',bn:'সরকারি প্রকল্প সম্পর্কে প্রশ্ন করুন…',te:'ప్రభుత్వ పథకాల గురించి అడగండి…'}[language]}
$('language').addEventListener('change',e=>{language=e.target.value;translate();try{localStorage.setItem('ssa_lang',language)}catch{}});
$('theme').addEventListener('click',()=>{document.body.classList.toggle('dark');const dark=document.body.classList.contains('dark');$('theme').textContent=dark?'☀':'☾';try{localStorage.setItem('ssa_theme',dark?'dark':'light')}catch{}});
try{if(localStorage.getItem('ssa_theme')==='dark')$('theme').click();const l=localStorage.getItem('ssa_lang');if(LANG[l]){language=l;$('language').value=l}}catch{}
translate();
function getProfile(){return{name:$('farmer-name').value.trim(),state:$('farmer-state').value,district:$('farmer-district').value.trim(),crop:$('farmer-crop').value,season:$('farmer-season').value,land_hectares:$('farmer-land').value,ownership:$('farmer-ownership').value}}
function choiceScheme(key){selectedScheme=key;$('research-scheme').value=key;$('application-scheme').value=key}
$('find-schemes').addEventListener('click',async()=>{profile=getProfile();try{const resp=await jsonApi('/api/eligibility',profile);$('match-summary').textContent=`${profile.state} • ${profile.district} • ${profile.crop} • ${profile.land_hectares} hectares`;
 $('scheme-results').innerHTML=resp.results.map(x=>{const s=schemeInfo[x.scheme];return `<article class="scheme-card"><div class="scheme-title-line"><span class="scheme-icon">${s.icon}</span><div><span class="pill">${x.status==='INCOMPLETE'?'Profile incomplete':'Requires official verification'}</span><h3>${esc(s.name)}</h3></div></div><p>${esc(s.desc)}</p><strong style="font-size:12px">${x.missing.length?'Missing profile details:':'Key verification points:'}</strong><ul>${(x.missing.length?x.missing:x.reasons.slice(0,3)).map(v=>`<li>${esc(v)}</li>`).join('')}</ul><div class="scheme-buttons"><button class="btn primary" data-plan="${x.scheme}">Prepare application →</button><button class="btn outline" data-investigate="${x.scheme}">Research ↗</button></div></article>`}).join('');
 document.querySelectorAll('[data-plan]').forEach(b=>b.onclick=()=>{choiceScheme(b.dataset.plan);go('application')});document.querySelectorAll('[data-investigate]').forEach(b=>b.onclick=()=>{choiceScheme(b.dataset.investigate);go('research')});go('schemes')
 }catch(err){notify(err.message)}});
$('run-research').onclick=async()=>{const b=$('run-research');const area=$('research-output');b.disabled=true;b.textContent='Researching live government page…';area.className='research-output';area.innerHTML='<div class="empty-illustration">⌛</div><h3>Investigating official source…</h3><p>This could take up to two minutes.</p>';
 try{const d=await jsonApi('/api/research',{scheme:$('research-scheme').value});area.className='research-output has-result';area.innerHTML=`<span class="pill">✓ Live TinyFish extraction · Requires verification</span><h3>${esc(d.name)}</h3><ol>${d.lines.slice(0,14).map(v=>`<li>${esc(v)}</li>`).join('')}</ol><a href="${esc(d.source)}" target="_blank" rel="noopener noreferrer" class="source-link">Official source ↗</a><small class="note">${esc(d.warning)}</small>`;notify('Live research finished');
 }catch(e){area.className='research-output';area.innerHTML=`<div class="empty-illustration">!</div><h3>Live research unavailable</h3><p>${esc(e.message)}</p><p>Starter reference documents remain available in the chatbot.</p>`}
 finally{b.disabled=false;b.innerHTML='Research government website ↗'}};
// Runny: natural conversation + evidence-grounded scheme chat.
let runnyHistory = [];
function bubble(text,role){
 const d=document.createElement('div');d.className='message '+role;
 d.textContent=text;$('chat-messages').appendChild(d);
 $('chat-messages').scrollTop=$('chat-messages').scrollHeight;return d;
}
$('chat-form').onsubmit=async e=>{
 e.preventDefault();const input=$('chat-question');const question=input.value.trim();if(!question)return;
 input.value='';bubble(question,'user');const wait=bubble('Runny is thinking… 🌱','assistant');
 const sentHistory=runnyHistory.slice(-6);
 try{
  const d=await jsonApi('/api/chat',{question,language,history:sentHistory});
  const cited=(d.sources||[]).length? '\n\nSources: '+[...new Set(d.sources.map(x=>x.url))].join(' · '):'';
  wait.textContent=d.answer+cited;
  runnyHistory.push({role:'user',content:question},{role:'assistant',content:d.answer});
  runnyHistory=runnyHistory.slice(-8);
 }catch(err){wait.textContent='Oops! 🌻 '+err.message+' Please try again.'}
 $('chat-messages').scrollTop=$('chat-messages').scrollHeight;
};
document.querySelectorAll('[data-ask]').forEach(btn=>btn.addEventListener('click',()=>{
 $('chat-question').value=btn.dataset.ask;$('chat-form').requestSubmit();
}));

let docBusy=false;
async function renderChecklist(){const scheme=$('application-scheme').value;choiceScheme(scheme);let d;try{d=await getApi('/api/document-checklist/'+scheme)}catch(err){notify(err.message);return}if(scheme!==$('application-scheme').value)return;
 $('doc-progress-text').textContent=`${d.done} of ${d.total} ready`;$('doc-progress-bar').style.width=`${d.total?100*d.done/d.total:0}%`;
 $('document-list').innerHTML=d.docs.map(doc=>{const ready=doc.status!=='pending';return `<div class="doc-row ${ready?'ready':''}"><div><div class="doc-name"><span class="doc-check">${ready?'✓':'○'}</span>${esc((DOC_LABELS[language]||DOC_LABELS.en)[doc.id]||doc.name)}</div><p class="doc-desc">${esc(doc.note)}</p></div><div class="doc-controls"><span class="status-label ${ready?'done':''}">${ready?(doc.status==='file_checked'?'Demo file checked':'Ready ✓'):'Pending'}</span><button data-mark="${doc.id}">${ready?'Undo':'Mark ready'}</button><label class="upload-label">${ready?'Replace demo':'Demo upload'}<input type="file" data-upload="${doc.id}" accept=".pdf,.png,.jpg,.jpeg"></label></div></div>`}).join('');
 $('document-list').querySelectorAll('[data-mark]').forEach(b=>b.onclick=async()=>{if(docBusy)return;docBusy=true;try{const doc=d.docs.find(x=>x.id===b.dataset.mark);await jsonApi('/api/document-check/'+scheme+'/'+doc.id,{complete:doc.status==='pending'});await renderChecklist()}catch(err){notify(err.message)}finally{docBusy=false}});
 $('document-list').querySelectorAll('[data-upload]').forEach(inp=>inp.onchange=async()=>{const file=inp.files?.[0];if(!file)return;if(file.size>5*1024*1024){notify('Max file size is 5 MB. Use fictional or redacted demo files only.');return}const form=new FormData();form.append('file',file);try{const r=await fetch('/api/document-check/'+scheme+'/'+inp.dataset.upload,{method:'POST',body:form});const x=await r.json();if(!r.ok)throw Error(x.error||'Upload failed');notify('Demo file inspected and discarded (not saved).');await renderChecklist()}catch(err){notify(err.message)}});
 $('official-apply').href=scheme==='pmkisan'?'https://www.pmkisan.gov.in/RegistrationFormupdated.aspx':'https://pmfby.gov.in/';
}
$('application-scheme').onchange=()=>{renderChecklist();renderPreview()};
async function renderPreview(){profile=getProfile();let data;try{data=await jsonApi('/api/prepare',{scheme:$('application-scheme').value,profile})}catch(err){notify(err.message);return};$('application-preview').innerHTML=[['Scheme',data.scheme],['Farmer name',profile.name],['State',profile.state],['District',profile.district],['Main crop',profile.crop],['Season',profile.season],['Land (hectares)',profile.land_hectares],['Land access',profile.ownership],['Documents marked ready',data.documents.done+' / '+data.documents.total],['Official eligibility','Not verified']].map(([label,val])=>`<div class="preview-row"><span>${esc(label)}</span><b>${esc(val||'Missing')}</b></div>`).join('');const msg=data.eligibility.missing.length?'Missing profile details: '+data.eligibility.missing.join(', '):'Profile fields are filled. Scheme rules and actual eligibility require official verification.';$('application-notice').textContent=msg+' No government submission has occurred.'}
$('prepare-application').onclick=()=>renderPreview();
$('save-application').onclick=async()=>{if(!$('review-confirmed').checked){notify('Please review the form and tick the confirmation.');return}try{const d=await jsonApi('/api/save-draft',{scheme:$('application-scheme').value,profile:getProfile(),review_confirmed:true});notify('Draft #'+d.id+' saved locally; NOT submitted to government.');go('applications')}catch(e){notify(e.message)}};
$('inspect-form').onclick=async()=>{const b=$('inspect-form');if(!confirm('Allow TinyFish to read the PUBLIC official form fields only? No farmer data will be submitted.'))return;b.disabled=true;b.textContent='Inspecting public form…';try{const d=await jsonApi('/api/assist-form',{scheme:$('application-scheme').value,consent:true});$('application-notice').textContent='Official page inspection: '+d.public_fields.join(' · ')+'. '+d.note;notify('Public fields found (read-only)')}catch(err){notify(err.message)}finally{b.disabled=false;b.textContent='TinyFish: inspect public form ↗'}};
// Application Tracker — only local drafts and explicitly fictional examples.
let trackerRecords=[];
let trackerFilter='all';
let openRecord=null;
const steps=['Application submitted','Under verification','Approved','Payment released'];
const stageLabel=['Draft saved','Submitted · simulated','Verification · simulated','Approved · simulated','Payment released · simulated'];
const palette={draft:'#7f95a0',submitted:'#63b2e9',review:'#f1b54e',approved:'#0f9d6a',paid:'#5e75d8'};
function appStatus(rec){
 if(rec.origin==='LOCAL_DRAFT')return {txt:'Local draft · not submitted',css:'draft'};
 const val=rec.stage;
 return val===1?{txt:'Submitted · demo',css:'submitted'}:val===2?{txt:'Under verification · demo',css:'review'}:val===3?{txt:'Approved · demo',css:'approved'}:{txt:'Payment released · demo',css:'paid'};
}
function localDate(iso){
 const d=new Date(iso);return Number.isNaN(d.valueOf())?'Unknown date':d.toLocaleDateString(language==='en'?'en-IN':language+'-IN',{day:'numeric',month:'short',year:'numeric'});
}
function makeTimeline(rec){
 const isDraft=rec.origin==='LOCAL_DRAFT';
 const labels=isDraft?['Draft saved','Form ready','Official submission','Govt. review']:steps;
 const done=isDraft?1:rec.stage;
 const bar= Math.round((done-1)/(labels.length-1)*100);
 return `<div class="journey-wrap"><div class="journey-rail"><span style="width:${Math.max(0,bar)}%"></span></div><div class="journey-steps">${labels.map((label,i)=>{
   const complete=isDraft?i===0:i<done;
   const current=isDraft?i===0:i===Math.max(0,done-1);
   return `<div class="journey-step ${complete?'complete':''} ${current?'current':''}"><span class="step-dot">${complete?'✓':i+1}</span><span class="step-label">${esc(label)}</span></div>`
 }).join('')}</div></div>`;
}
function drawTrackerCharts(records){
 $('metric-total').textContent=records.length;
 $('metric-drafts').textContent=records.filter(x=>x.origin==='LOCAL_DRAFT').length;
 $('metric-demo').textContent=records.filter(x=>x.origin==='SIMULATED').length;
 $('donut-count').textContent=records.length;
 const counts=[
  {name:'Saved drafts',num:records.filter(x=>x.origin==='LOCAL_DRAFT').length,color:palette.draft},
  {name:'Demo: submitted',num:records.filter(x=>x.origin==='SIMULATED'&&x.stage===1).length,color:palette.submitted},
  {name:'Demo: verification',num:records.filter(x=>x.origin==='SIMULATED'&&x.stage===2).length,color:palette.review},
  {name:'Demo: approved / paid',num:records.filter(x=>x.origin==='SIMULATED'&&x.stage>=3).length,color:palette.approved}
 ];
 let cursor=0;const grad=[];
 for(const row of counts){if(!row.num)continue;const next=cursor+100*row.num/records.length;
  grad.push(`${row.color} ${cursor.toFixed(2)}% ${next.toFixed(2)}%`);cursor=next;}
 $('tracker-donut').style.background=records.length?'conic-gradient('+grad.join(',')+')':'conic-gradient(#d9e7e0 0% 100%)';
 $('tracker-legend').innerHTML=counts.map(x=>`<div class="legend-item"><span class="legend-dot" style="background:${x.color}"></span><span>${esc(x.name)}</span><b>${x.num}</b></div>`).join('');
 const now=new Date(); now.setHours(0,0,0,0);const points=[];
 for(let i=6;i>=0;i--){const date=new Date(now);date.setDate(now.getDate()-i);
  const count=records.filter(x=>{const d=new Date(x.created);return !isNaN(d)&&d.toDateString()===date.toDateString()}).length;
  points.push({day:date.toLocaleDateString('en-IN',{weekday:'short'}),n:count});}
 const max=Math.max(1,...points.map(x=>x.n));
 $('activity-chart').innerHTML=points.map((x,i)=>`<div class="activity-col"><span class="activity-value">${x.n?x.n:''}</span><div class="activity-track"><div class="activity-bar" style="height:${Math.max(x.n?10:2,100*x.n/max)}%;animation-delay:${i*55}ms"></div></div><small>${x.day}</small></div>`).join('');
 $('activity-chart').setAttribute('aria-label',points.map(x=>x.day+': '+x.n).join(', '));
}
function renderTrackingRecords(){
 const filtered=trackerRecords.filter(x=>trackerFilter==='all'||(trackerFilter==='draft'?x.origin==='LOCAL_DRAFT':x.origin==='SIMULATED'));
 const area=$('draft-list');
 if(!filtered.length){area.innerHTML=`<div class="tracking-empty"><div class="empty-circle">☘</div><h3>Nothing here yet</h3><p>${trackerFilter==='draft'?'Prepare your first application draft.':trackerFilter==='demo'?'Click “Show demo progress” for fictional examples.':'Create a draft or try the sample tracking dashboard.'}</p><button class="btn primary" type="button" data-nav="application">Create a draft ↗</button></div>`;
  area.querySelector('[data-nav]').onclick=()=>go('application');return;}
 area.innerHTML=filtered.map((rec,i)=>{
   const status=appStatus(rec),isDemo=rec.origin==='SIMULATED',opened=rec.id===openRecord;
   return `<article class="tracker-item ${opened?'expanded':''}" style="--delay:${Math.min(i,6)*65}ms" data-record="${esc(rec.id)}">
     <button type="button" class="tracker-item-top" data-expand="${esc(rec.id)}" aria-expanded="${opened?'true':'false'}">
       <span class="tracker-item-icon">${rec.scheme==='pmkisan'?'🌾':'🛡️'}</span>
       <span class="tracker-item-info"><strong>${esc(rec.name)}</strong><small>${isDemo?'SIMULATED RECORD':'MY LOCAL DRAFT'} · ${localDate(rec.created)} · ${esc(rec.id)}</small></span>
       <span class="status-chip ${status.css}">${esc(status.txt)}</span>
       <span class="tracker-chevron">⌄</span>
     </button>
     ${makeTimeline(rec)}
     ${opened?`<div class="tracker-expanded"><div class="expanded-head"><b>${isDemo?'Illustrative tracking detail':'Your draft details'}</b><span>${isDemo?'DEMO ONLY':'NOT SUBMITTED'}</span></div>
       <p>${esc(rec.note)}</p><div class="expanded-actions"><button class="btn outline" type="button" data-navapp="${esc(rec.scheme)}">Review documents ↗</button><a href="${rec.scheme==='pmkisan'?'https://pmkisan.gov.in/':'https://pmfby.gov.in/'}" target="_blank" rel="noopener noreferrer">Check official portal ↗</a></div></div>`:''}
    </article>`;
 }).join('');
 area.querySelectorAll('[data-expand]').forEach(el=>el.onclick=()=>{openRecord=openRecord===el.dataset.expand?null:el.dataset.expand;renderTrackingRecords()});
 area.querySelectorAll('[data-navapp]').forEach(el=>el.onclick=()=>{choiceScheme(el.dataset.navapp);go('application')});
}
async function loadDrafts(){
 try{trackerRecords=await getApi('/api/applications');drawTrackerCharts(trackerRecords);renderTrackingRecords();
 $('clear-demo').style.display=trackerRecords.some(x=>x.origin==='SIMULATED')?'inline-flex':'none';
 $('demo-load').textContent=trackerRecords.some(x=>x.origin==='SIMULATED')?'✦ Demo examples loaded':'✦ Show demo progress';
 }catch(err){$('draft-list').innerHTML=`<div class="tracking-empty">${esc(err.message)}</div>`}
}
document.querySelectorAll('[data-filter]').forEach(btn=>btn.addEventListener('click',()=>{
 trackerFilter=btn.dataset.filter;document.querySelectorAll('[data-filter]').forEach(n=>n.classList.toggle('selected',n===btn));renderTrackingRecords();
}));
$('demo-load').onclick=async()=>{try{
 await jsonApi('/api/demo-tracking',{consent:true});trackerFilter='all';
 document.querySelectorAll('[data-filter]').forEach(n=>n.classList.toggle('selected',n.dataset.filter==='all'));
 await loadDrafts();notify('Three fictional tracking examples loaded — not official government records.');
 }catch(err){notify(err.message)}};
$('clear-demo').onclick=async()=>{try{await jsonApi('/api/demo-tracking/clear',{});openRecord=null;await loadDrafts();notify('Demo records cleared.')}catch(err){notify(err.message)}};
(async()=>{try{const d=await getApi('/api/health');$('api-indicators').textContent=(d.tinyfish?'● TinyFish connected':'○ TinyFish key needed')+'  ·  '+(d.openrouter?'● OpenRouter connected':'○ OpenRouter key needed')}catch{ $('api-indicators').textContent='API status unknown'}})();
// Initial state. Kept offline-safe: there are no real identity details or website submissions.
profile=getProfile();go('home');
